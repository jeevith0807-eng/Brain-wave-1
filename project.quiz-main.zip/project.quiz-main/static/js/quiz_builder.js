document.addEventListener("DOMContentLoaded", function () {
  const questionList = document.getElementById("questionList");
  const template = document.getElementById("questionTemplate");
  const addBtn = document.getElementById("addQuestionBtn");
  const form = document.getElementById("quizBuilderForm");

  function renumberQuestions() {
    const cards = questionList.querySelectorAll(".question-card");
    cards.forEach((card, index) => {
      card.querySelector(".question-number").textContent = "Question " + (index + 1);
    });
  }

  function addQuestion() {
    const clone = template.content.cloneNode(true);
    const card = clone.querySelector(".question-card");

    card.querySelector(".remove-question-btn").addEventListener("click", function () {
      card.remove();
      renumberQuestions();
    });

    questionList.appendChild(clone);
    renumberQuestions();
  }

  addBtn.addEventListener("click", addQuestion);

  // Start every quiz with one question ready to fill in.
  addQuestion();

  // Before the form submits, convert each question's selected radio
  // button into a hidden "correct_option" field so the server receives
  // one correct answer letter per question, in the same order.
  form.addEventListener("submit", function (event) {
    const cards = questionList.querySelectorAll(".question-card");

    for (const card of cards) {
      const checked = card.querySelector(".correct-radio:checked");
      if (!checked) {
        event.preventDefault();
        alert("Please mark the correct answer for every question.");
        return;
      }
      const hidden = document.createElement("input");
      hidden.type = "hidden";
      hidden.name = "correct_option";
      hidden.value = checked.dataset.option;
      card.appendChild(hidden);
    }
  });
});
