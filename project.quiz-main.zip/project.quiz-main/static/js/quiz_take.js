document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector(".quiz-attempt");
  if (!form) return;

  const barFill = document.querySelector(".bar-fill");
  const questionGroups = {};

  form.querySelectorAll('input[type="radio"]').forEach((radio) => {
    if (!questionGroups[radio.name]) questionGroups[radio.name] = [];
    questionGroups[radio.name].push(radio);

    radio.addEventListener("change", function () {
      questionGroups[radio.name].forEach((r) => {
        r.closest(".opt").classList.toggle("selected", r.checked);
      });
      updateProgress();
    });
  });

  function updateProgress() {
    if (!barFill) return;
    const total = Object.keys(questionGroups).length;
    const answered = Object.values(questionGroups).filter((group) =>
      group.some((r) => r.checked)
    ).length;
    barFill.style.width = total ? (answered / total) * 100 + "%" : "0%";
  }
});