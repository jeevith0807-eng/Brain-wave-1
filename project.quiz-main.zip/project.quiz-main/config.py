import os

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    # SECRET_KEY is used by Flask to sign session cookies. In production
    # (Render) set this as an Environment Variable. Locally it falls back
    # to a default so beginners can still run the app.
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-this")

    # DATABASE_URL is provided automatically by Render when you attach a
    # PostgreSQL database. Locally, no DATABASE_URL is set, so we fall back
    # to a simple SQLite file -> perfect for a beginner / school project.
    database_url = os.environ.get("DATABASE_URL", "")

    # Render's Postgres URL starts with "postgres://" but SQLAlchemy needs
    # "postgresql://" - this line fixes that automatically.
    if database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)

    SQLALCHEMY_DATABASE_URI = database_url or f"sqlite:///{os.path.join(basedir, 'brainwave.db')}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
